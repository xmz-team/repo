#import <PassKitCore/PKPaymentDevice.h>
