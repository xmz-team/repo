#import <SplashBoard/XBApplicationSnapshot.h>
