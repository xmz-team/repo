#!/bin/bash

cd /var/jb/theos || exit 1
current_time=$(date +"%Y-%m-%d_%H-%M-%S")

mkdir -p Backup-sdks/zip
mkdir -p Backup-sdks/zstd

echo "開始 zip 壓縮..."
zip -r -9 sdks.zip sdks/ -v
echo "壓縮完成正在移動到備份目錄中..."
mkdir -p Backup-sdks/zip/$current_time && mv sdks.zip Backup-sdks/zip/$current_time/
echo "zip處理完成"

echo "開始 zstd 壓縮..."
tar -I 'zstd -19 -v --progress' -cf sdks.tar.zst sdks/
echo "壓縮完成正在移動到目錄中..."
mkdir -p Backup-sdks/zstd/$current_time && mv sdks.tar.zst Backup-sdks/zstd/$current_time/
echo "zstd處理完成"

echo "zip目錄: /var/jb/theos/Backup-sdks/zip/$current_time/sdks.zip"
echo "zst目錄: /var/jb/theos/Backup-sdks/zstd/$current_time/sdks.tar.zst"