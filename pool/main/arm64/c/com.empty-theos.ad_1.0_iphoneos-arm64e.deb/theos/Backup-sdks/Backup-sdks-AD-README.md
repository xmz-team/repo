# Backup-sdks-AD-README.md

# sdks备份目录

# 如果您需要备份sdks，请在/var/jb/theos/中运行Backup-sdks.sh脚本以完成备份。

# 如果您不需要,请忽略

# English:

# sdks backup directory

# If you need to back up sdks, please run the Backup-sdks.sh script in /var/jb/theos/ to complete the backup.

# If you don't need it, please ignore it.