//
//  CXTransaction.h
//  CallKit
//
//  Copyright © 2015 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CallKit/CXBase.h>

NS_ASSUME_NONNULL_BEGIN

@class CXAction;

CX_CLASS_AVAILABLE(ios(10.0))
@interface CXTransaction : NSObject <NSCopying, NSSecureCoding>

/// Unique ID
@property (nonatomic, readonly, copy) NSUUID *UUID;

/// Whether all actions have been completed
@property (nonatomic, readonly, assign, getter=isComplete) BOOL complete;

/// The list of actions contained by the receiver
@property (nonatomic, readonly, copy) NSArray<__kindof CXAction *> *actions;

- (instancetype)initWithActions:(NSArray<CXAction *> *)actions NS_DESIGNATED_INITIALIZER;
- (instancetype)initWithAction:(CXAction *)action;

/// Add the provided action to the receiver's list of actions
- (void)addAction:(CXAction *)action;

@end

NS_ASSUME_NONNULL_END
