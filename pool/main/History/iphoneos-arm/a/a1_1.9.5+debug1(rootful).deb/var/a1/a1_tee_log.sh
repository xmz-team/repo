#!/bin/bash
# a1_tee

: '

Created by AD on 7/12/25
Copyright (c) 2025 AD All rights reserved.

'

jb_a1=""

for dir in /a1 /var/a1 /var/jb/a1 /rootfs/var/a1; do
    if [ -d "$dir" ]; then
        jb_a1="$dir"
        break
    fi
done

if [ -z "$jb_a1" ]; then
    while IFS= read -r dir; do
        if [ -d "$dir" ] && 
           [[ "$dir" == /* ]] && 
           [[ ! "$dir" =~ ^/usr/share/(doc|man|locale) ]] &&
           [[ ! "$dir" =~ /doc$ ]] &&
           [[ "$dir" =~ /a1$ ]]; then
            jb_a1="$dir"
            break
        fi
    done < <(dpkg -L a1 2>/dev/null | xargs -I {} dirname {} | sort -u)
fi

if [ -n "$jb_a1" ]; then
    if [ -f "$jb_a1/autofonf.ini" ]; then
        source "$jb_a1/autofonf.ini"
    elif [ -f "$jb_a1/a1_ADautoconf.sh" ]; then
        source "$jb_a1/a1_ADautoconf.sh"
        [ -f "$jb_a1/autofonf.ini" ] && source "$jb_a1/autofonf.ini"
    fi
fi


tee "$jb_a1/a1.log" < /dev/null > /dev/null
tee "$jb_a1/a1error.log" < /dev/null > /dev/null

echo "The log has been cleaned up."