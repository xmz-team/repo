#! /bin/bash
# a1_ADautoconf
# name: A1 autoconf
# update time: 13:02/27/1/26

jb_a1=""

for dir in /a1 /var/a1 /var/jb/a1 /rootfs/var/a1; do
    if [ -d "$dir" ]; then
        jb_a1="$dir"
        break
    fi
done

if [ -z "$jb_a1" ]; then
    while IFS= read -r dir; do
        if [ -d "$dir" ] && 
           [[ "$dir" == /* ]] && 
           [[ ! "$dir" =~ ^/usr/share/(doc|man|locale) ]] &&
           [[ ! "$dir" =~ /doc$ ]] &&
           [[ "$dir" =~ /a1$ ]]; then
            jb_a1="$dir"
            break
        fi
    done < <(dpkg -L a1 2>/dev/null | xargs -I {} dirname {} | sort -u)
fi

if [ -n "$jb_a1" ]; then
    if [ -f "$jb_a1/autofonf.ini" ]; then
        source "$jb_a1/autofonf.ini"
    elif [ -f "$jb_a1/a1_ADautoconf.sh" ]; then
        source "$jb_a1/a1_ADautoconf.sh"
        [ -f "$jb_a1/autofonf.ini" ] && source "$jb_a1/autofonf.ini"
    fi
fi

source "$jb_a1/ADautoconf.sh"

rm -f "$jb_a1/autofonf.ini"

# conf
# export jblocal="$jbusr/local"
# export jbusrbin="$jbusr/bin"

config_file="$jb_a1/autofonf.ini"

a1_auto_conf() {
    cat >> "$config_file" << EOF
# a1 conf
export ps="$sys_bin/ps"
export jb_a1="$jb_a1"
export a1_expand="$jb_a1/a1.expand"
export jblocal="$jbusr/local"
export a1_exe="$jblocal/bin/a1"
export a1ctl_exe="$jblocal/bin/a1ctl"
export a1hub_exe="$jblocal/bin/a1hub"
export a1_return_exe="$jblocal/bin/a1-return"
export a1_conf="$jb_a1/config.conf"
export a1_inside="$jb_a1/inside.ini"
export jbsbin="$jbusr/sbin"
export jbusrbin="$jbusr/bin"

# a1 module conf
export jq="$jbusrbin/jq"
export zip="$jbusrbin/zip"
export unzip="$jbusr/bin/unzip"
export find="$jbusrbin/find"
export grep="$jbusrbin/grep"
export sed="$jbusrbin/sed"
export mkdir="$jbusrbin/mkdir"
export rm="$jbusrbin/rm"
export mv="$jbusrbin/mv"
export cp="$jbusrbin/cp"
export date="$jbusrbin/date"

EOF
}

if [ -f "$jb_a1/autofonf.ini" ]; then
    a1_auto_conf
else
    auto_conf
    a1_auto_conf
fi
