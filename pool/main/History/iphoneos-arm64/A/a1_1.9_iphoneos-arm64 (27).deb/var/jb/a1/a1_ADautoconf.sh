#! /bin/sh
# a1_ADautoconf
# name: A1
# update time: 13:13/1/20/26
if test -d /var/jb; then
    jb="/var/jb"
    jb_a1="$jb/a1"
elif test -d /rootfs; then
    jb=""
    jb_a1="$jb/rootfs/var/a1"
else
    jb=""
    jb_a1="$jb/var/a1"
fi

. "$jb_a1/ADautoconf.sh" 2>/dev/null

# conf
export jblocal="$jbusr/local"

config_file="$jb_a1/autofonf.ini"

a1_auto_conf() {
    cat >> "$config_file" << EOF
# a1 conf
export ps="$sys_bin/ps"
export jb_a1="$jb_a1"
export a1_expand="$jb_a1/a1.expand"
export jblocal="$jbusr/local"
export a1_exe="$jblocal/bin/a1"
export a1ctl_exe="$jblocal/bin/a1ctl"
export a1hub_exe="$jblocal/bin/a1hub"
export a1_return_exe="$jblocal/bin/a1-return"
export a1_conf="$jb_a1/config.conf"
export a1_inside="$jb_a1/inside.ini"
export jbsbin="$jbusr/sbin"

EOF
}

if test -f "$jb_a1/autofonf.ini"; then
    a1_auto_conf
else
    auto_conf
    a1_auto_conf
fi
