#!/bin/bash
# a1_tee

: '

Created by AD on 7/12/25
Copyright (c) 2025 AD All rights reserved.

'

if [ -d /var/jb ]; then
    jb="/var/jb"
    jb_a1="$jb/a1"
elif [ -d /rootfs ]; then
    jb=""
    jb_a1="$jb/rootfs/var/a1"
else
    jb=""
    jb_a1="$jb/var/a1"
fi

if [ -f "$jb_a1/autofonf.ini" ]; then
    source "$jb_a1/autofonf.ini"
else
    if [ -f "$jb_a1/a1_ADautoconf.sh" ]; then
        "$jb_a1/a1_ADautoconf.sh"
        source "$jb_a1/autofonf.ini"
    fi
fi

tee "$jb_a1/a1.log" < /dev/null > /dev/null
tee "$jb_a1/a1error.log" < /dev/null > /dev/null

echo "The log has been cleaned up."