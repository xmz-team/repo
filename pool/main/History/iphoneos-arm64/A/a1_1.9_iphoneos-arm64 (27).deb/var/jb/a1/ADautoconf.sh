#! /bin/sh
# ADautoconf
####============== 說明 ==============####
# 半通用,跨環境的配置生成腳本               #
# 生成一個基礎環境變量配置文件              #
# 適用於 rootful,rootless,roothide 環境  #
####================================####

dpkgpath=$(which dpkg)
ios_arm="iphoneos-arm"
ios_arm64="iphoneos-arm64"
ios_arm64e="iphoneos-arm64e"

jb=""
JB=""
sys_bin=""
sys_usr=""
jbbin=""
jbusr=""
rootfs=""
ios_aarch=""

if test -d /var/jb; then
    jb="/var/jb"
    JB="$jb"
elif test -d /rootfs; then
    jb=""
    JB="$jb"
else
    jb=""
    JB="$jb"
fi

if test -x "$dpkgpath"; then
    dpkgarch=$($dpkgpath --print-architecture)
    
    case "$dpkgarch" in
        "$ios_arm")
            jb=""
            JB="$jb"
            sys_bin="/bin"
            sys_usr="/usr/bin"
            jbbin="$jb/bin"
            jbusr="$jb/usr"
            rootfs=""
            ios_aarch="arm"
            ;;
        "$ios_arm64")
            if test -f "$jb/.installed_dopamine" ||
               test -f "$jb/.xinamine" ||
               test -f "$jb/.procursus_strapped"; then
                jb="/var/jb"
                JB="$jb"
                sys_bin="/bin"
                sys_usr="/usr/bin"
                jbbin="$jb/bin"
                jbusr="$jb/usr"
                rootfs=""
            else
                jb=""
                JB="$jb"
                sys_bin="/bin"
                sys_usr="/usr/bin"
                jbbin="$jb/bin"
                jbusr="$jb/usr"
                rootfs=""
            fi
            ios_aarch="arm64"
            ;;
        "$ios_arm64e")
            jb=""
            JB="$jb"
            sys_bin="/rootfs/bin"
            sys_usr="/rootfs/usr/bin"
            jbbin="$jb/bin"
            jbusr="$jb/usr"
            rootfs="/rootfs"
            ios_aarch="arm64e"
            ;;
            
        *)
            if test -d "/var/jb" &&
               test -f "/var/jb/.installed_dopamine"; then
                ios_aarch="arm64"
                jb="/var/jb"
                JB="$jb"
            elif test -d "/rootfs"; then
                ios_aarch="arm64e"
                rootfs="/rootfs"
            fi
            ;;
    esac
else
    if test -d "/var/jb" &&
       test -f "/var/jb/.installed_dopamine"; then
        ios_aarch="arm64"
        jb="/var/jb"
        JB="$jb"
    elif test -d "/rootfs"; then
        ios_aarch="arm64e"
        rootfs="/rootfs"
    elif test -d "/var/jb"; then
        ios_aarch="arm64"
        jb="/var/jb"
        JB="$jb"
    fi
fi

: ${sys_bin:="/bin"}
: ${sys_usr:="/usr/bin"}
: ${jbbin:="$jb/bin"}
: ${jbusr:="$jb/usr"}
: ${ios_aarch:="unknown"}

# pathpwd="$(pwd -P)"
ios_arch="$ios_aarch"

config_file="${1:-autofonf.ini}"

auto_conf() {
    cat >> "$config_file" << EOF
export jb="$jb";
export JB="$JB";
export sys_bin="$sys_bin";
export sys_usr="$sys_usr";
export jbbin="$jbbin";
export jbusr="$jbusr";
export rootfs="$rootfs";
export ios_arch="$ios_aarch";

EOF
}

if test "${BASH_SOURCE[0]}" = "$0"; then
    auto_conf "autofonf.ini"
fi
