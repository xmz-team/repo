#!/bin/bash

: '

Created by AD on 6/12/25
Copyright (c) 2025 AD All rights reserved.

'

if [ -d /var/jb ]; then
    jb="/var/jb"
    jb_a1="$jb/a1"
elif [ -d /rootfs ]; then
    jb=""
    jb_a1="$jb/rootfs/var/a1"
else
    jb=""
    jb_a1="$jb/var/a1"
fi

if [ -f "$jb_a1/autofonf.ini" ]; then
    source "$jb_a1/autofonf.ini"
else
    if [ -f "$jb_a1/a1_ADautoconf.sh" ]; then
        "$jb_a1/a1_ADautoconf.sh"
        source "$jb_a1/autofonf.ini"
    fi
fi

$jb/usr/sbin/sysctl kern.vm_page_free_min=20000
$jb/usr/sbin/sysctl kern.vm_page_free_reserved=256
$jb/usr/sbin/sysctl kern.memorystatus_kill_on_sustained_pressure_delay_ms=86400000
$jb/usr/sbin/sysctl kern.vm_max_delayed_work_limit=64