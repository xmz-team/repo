#!/usr/bin/env bash
# a1_tee

: '

Created by AD on 7/12/25
Copyright (c) 2025 AD All rights reserved.

'

# jb=/var/jb # rootless
jb="" # roothide

# jb_a1=$jb/a1 # rootless
jb_a1=$jb/rootfs/var/a1 # roothide

tee "$jb_a1/a1.log" < /dev/null > /dev/null
tee "$jb_a1/a1error.log" < /dev/null > /dev/null

echo "The log has been cleaned up."