#!/bin/sh -

: '

Created by AD on 6/12/25
Copyright (c) 2025 AD All rights reserved.

'

# jb=/var/jb # rootless
jb="" # roothide

$jb/usr/sbin/sysctl kern.vm_page_free_min=20000
$jb/usr/sbin/sysctl kern.vm_page_free_reserved=256
$jb/usr/sbin/sysctl kern.memorystatus_kill_on_sustained_pressure_delay_ms=86400000
$jb/usr/sbin/sysctl kern.vm_max_delayed_work_limit=64